package com.cs370.storemodel.model;

/**
 * Enumeration representing Aisle location in the Store
 */
public enum AisleLocation {
    floor,
    store_room
}
