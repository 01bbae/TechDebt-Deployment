package com.cs370.storemodel.model;

/**
 * Enumeration representing Customer's type
 */
public enum CustomerType {
    guest,
    registered
}
