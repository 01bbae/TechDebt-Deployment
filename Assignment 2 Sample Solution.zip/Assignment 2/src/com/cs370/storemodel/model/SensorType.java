package com.cs370.storemodel.model;

/**
 * Enumeration representing Sensor type
 */
public enum SensorType {
    microphone,
    camera
}
