package com.cs370.storemodel.model;

/**
 * Enumeration representing type of Appliances
 */
public enum ApplianceType {
    speaker,
    robot,
    turnstile
}
