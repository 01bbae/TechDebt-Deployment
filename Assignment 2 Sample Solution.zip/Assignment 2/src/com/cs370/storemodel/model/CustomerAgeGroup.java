package com.cs370.storemodel.model;

/**
 * Enumeration representing Customer's age group
 */
public enum CustomerAgeGroup {
    child,
    adult
}
