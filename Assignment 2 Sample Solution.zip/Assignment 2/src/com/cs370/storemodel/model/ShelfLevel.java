package com.cs370.storemodel.model;

/**
 * Enumeration representing Shelf level
 */
public enum ShelfLevel {
    high,
    medium,
    low
}
