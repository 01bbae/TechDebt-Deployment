package com.cs370.springdemo.model;

import org.junit.jupiter.api.Test;

class MessageTest {

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }

    @Test
    void getName() {
    }

    @Test
    void setName() {
    }

    @Test
    void getLastname() {
    }

    @Test
    void setLastname() {
    }

    @Test
    void getEmail() {
    }

    @Test
    void setEmail() {
    }
}